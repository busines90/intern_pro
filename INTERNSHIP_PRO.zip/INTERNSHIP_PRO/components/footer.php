<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <a href="tel:9750990856"><i class="fas fa-phone"></i> 9750990856</a>
         <a href="mailto:bh1097@srmist.edu"><i class="fas fa-envelope"></i> bh1097@srmist.edu</a>
         <a href="#"><i class="fas fa-map-marker-alt"></i> Chennai, india - 620020</a>
      </div>

      <div class="box">
         <a href="#home">Home</a>
         <a href="#about">About</a>
         <a href="bookings.php">My bookings</a>
         <a href="#reservation">Reservation</a>
         <a href="#gallery">Gallery</a>
         <a href="#contact">Contact</a>
         <a href="#reviews">Reviews</a>
      </div>

      <div class="box">
         <a href="https://www.facebook.com/basith.ahmed.5648">facebook <i class="fab fa-facebook-f"></i></a>
         <a href="https://www.instagram.com/basith.21/">instagram <i class="fab fa-instagram"></i></a>
         <a href="https://linkedin.com/in/basithoffi/">linkedin <i class="fab fa-linkedin"></i></a>
      </div>

   </div>

   <div class="credit">&copy; copyright @ 2022 by Mr. Basith Ahmed | all rights reseved!</div>

</section>

<!-- footer section ends -->